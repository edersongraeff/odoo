from odoo import models, fields, api


class MaintenancePlan(models.Model):
    _name = 'maintenance.plan'
    _description = 'Maintenance Plan'

    name = fields.Char('Name', required=True)
    equipment_id = fields.Many2one('maintenance.equipment', string='Equipment', required=True)
    change_type = fields.Selection([
        ('inspection', 'Inspection'),
        ('adjustment', 'Adjustment'),
        ('lubrication', 'Lubrication'),
        ('replacement', 'Replacement'),
    ], string='Change Type', required=True, default='inspection')
    hours_to_inspection = fields.Float(string='Hours to Inspection', required=True, default=0.0)
    hours_to_adjustment = fields.Float(string='Hours to Adjustment', required=True, default=0.0)
    hours_to_lubrication = fields.Float(string='Hours to Lubrication', required=True, default=0.0)
    hours_to_replacement = fields.Float(string='Hours to Replacement', required=True, default=0.0)

    @api.onchange('equipment_id')
    def onchange_equipment_id(self):
        if self.equipment_id:
            self.hours_to_inspection = self.equipment_id.hours_to_inspection
            self.hours_to_adjustment = self.equipment_id.hours_to_adjustment
            self.hours_to_lubrication = self.equipment_id.hours_to_lubrication
            self.hours_to_replacement = self.equipment_id.hours_to_replacement

    def predict_next_change_date(self):
        if self.change_type == 'inspection':
            return fields.Date.from_string(fields.Date.to_string(fields.Date.context_today())) + timedelta(hours=self.hours_to_inspection)
        elif self.change_type == 'adjustment':
            return fields.Date.from_string(fields.Date.to_string(fields.Date.context_today())) + timedelta(hours=self.hours_to_adjustment)
        elif self.change_type == 'lubrication':
            return fields.Date.from_string(fields.Date.to_string(fields.Date.context_today())) + timedelta(hours=self.hours_to_lubrication)
        elif self.change_type == 'replacement':
            return fields.Date.from_string(fields.Date.to_string(fields.Date.context_today())) + timedelta(hours=self.hours_to_replacement)