from odoo import models, fields, api
import nltk
nltk.data.path.append('/cloudclusters/persistent/nltk_data')
from nltk.corpus import wordnet as wn

                



class MotorHorimeter(models.Model):
    _name = 'motor.horimeter'
    _description = 'Motor Horimeter for Maintenance Equipment'

    equipment_id = fields.Many2one('maintenance.equipment', string="Maintenance Equipment", ondelete='cascade')
    motor_name = fields.Char("Motor Name")
    horimeter_value = fields.Float("Horimeter Value")
    horimeter_partial = fields.Float("Horimetro Parcial")
    last_updated = fields.Date("Last Updated")


class EquipmentMaintenanceHistory(models.Model):
    _name = 'equipment.maintenance.history'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Equipment Maintenance History'

    equipment_id = fields.Many2one('maintenance.equipment', string="Equipment", required=True, ondelete='cascade', index=True)
    category = fields.Char(string="Category", required=True, track_visibility='onchange')
    description = fields.Text(string="Description", required=True)
    date_performed = fields.Date(string="Date Performed", default=fields.Date.context_today, required=True)
    responsible_id = fields.Many2one('res.users', string="Responsible", required=True, index=True)
    machine_repair_order_id = fields.Many2one('machine.repair.order')
    notes = fields.Text(string="Notes")
    state = fields.Selection([('draft', 'Draft'), ('done', 'Done'), ('cancelled', 'Cancelled')], default='draft', string="Status", required=True)

    intervention_categories = {
        "Troca": [
            "troca", "substituido", "reposicao", "substituir", "substituido", "trocar", "substituindo", "montagem", "montado", "trocado"
        ],
        "Limpeza": [
            "limpeza", "lavagem", "limpo", "limpar", "lavando", "limpado"
        ],
        "Inspeção": [
            "inspecao", "conferido", "verificacao", "revisado", "diagnostico", "inspecionado", "inspecionar", "revisao", "verificado", "conferir", "inspecionado", "revisado"
        ],
        "Regulagem": [
            "regulagem", "ajuste", "ajustado", "regulada", "regulado", "apertado", "ajustar", "regular"
        ],
        "Calibração": [
            "calibracao", "calibragem", "calibradas", "calibrar", "calibrado", "calibrar"
        ],
        "Configuração": [
            "configuracao", "programacao", "parametrizacao", "configurar", "configurado"
        ],
        "Lubrificação": [
            "lubrificacao", "engraxar", "lubrificar", "engraxamento", "lubrificacao", "lubrificado", "engraxado", "engraxou"
        ]
    }

    identified_activities = fields.Text(string="Identified Activities")
    synonym_cache = {}

    @api.model
    def get_synonyms(self, word):
        # Use cache to avoid redundant WordNet calls
        if word not in self.synonym_cache:
            synonyms = set()
            for syn in wn.synsets(word, lang='por'):
                for lemma in syn.lemmas(lang='por'):
                    synonyms.add(lemma.name().replace('_', ' ').lower())
            self.synonym_cache[word] = list(synonyms)
        return self.synonym_cache[word]
        
    @api.model
    def normalize_word(self, word):
        word = unicodedata.normalize('NFD', word).encode('ascii', 'ignore').decode('utf-8')
        return word.lower()
 
        
    def analyze_description(self):
        description = self.normalize_word(self.description)
        if not description:
            return
    
        activities_found = set()
        for category, keywords in self.intervention_categories.items():
            for keyword in keywords:
                # Garante que os sinônimos sejam buscados apenas uma vez
                if keyword not in self.synonym_cache:
                    self.get_synonyms(self.normalize_word(keyword))
                extended_keywords = self.synonym_cache[keyword]
    
                # Adicionando contexto na busca por padrões
                for ext_keyword in extended_keywords:
                    pattern = r'\b{}\b'.format(re.escape(self.normalize_word(ext_keyword)))
                    if re.search(pattern, description):
                        activities_found.add(category)
                        break  # Para após a primeira correspondência encontrada para uma categoria
    
        self.identified_activities = ', '.join(activities_found)

    @api.model
    def create(self, vals):
        record = super(EquipmentMaintenanceHistory, self).create(vals)
        record.analyze_description()
        return record

    def write(self, vals):
        if not self.env.context.get('bypass_analyze_description'):
            self.with_context(bypass_analyze_description=True).analyze_description()
        return super(EquipmentMaintenanceHistory, self).write(vals)

    @api.model
    def action_edit_record(self):
        # Este método pode ser modificando para incluir lógica específica ou simplesmente return um action dict que abre o form view.
        action = {
            'type': 'ir.actions.act_window',
            'name': 'Edit Maintenance History',
            'res_model': 'equipment.maintenance.history',
            'view_mode': 'form',
            'res_id': self.id,
            'target': 'current',
            'flags': {'form': {'action_buttons': True}}
        }
        return action

