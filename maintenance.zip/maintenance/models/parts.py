from odoo import models, fields, api

class SparePartsChangeHistory(models.Model):
    _name = 'equipment.maintenance.part.history'
    _description = 'Histórico de Trocas de Peças'

    equipment_id = fields.Many2one('maintenance.equipment', string="Equipment", required=True, ondelete='cascade', index=True)
    spare_part_id = fields.Many2one('product.product', string='Spare Part', required=True, ondelete='restrict', index=True)
    quantity = fields.Float(string='Quantity', required=True, default=1.0)
    hours_to_change = fields.Float(string='Hours to Change', required=True, default=0.0)
    change_date = fields.Date(string='Change Date', required=True, default=fields.Date.context_today)
    service_order_id = fields.Many2one('machine.repair.order', string='Service Order')

    equipment_name = fields.Char(related='equipment_id.name', string='Equipment Name')

    @api.depends('hours_to_change')
    def _compute_adjusted_interval(self):
        for record in self:
            record.adjusted_interval = record.hours_to_change

    adjusted_interval = fields.Float(string='Adjusted Interval', compute='_compute_adjusted_interval')

    @api.onchange('equipment_id')
    def onchange_equipment_id(self):
        if self.equipment_id:
            self.equipment_name = self.equipment_id.name
            self.spare_part_id = False
            self.quantity = 0.0
            self.hours_to_change = 0.0

    @api.depends('spare_part_id')
    def _compute_spare_part_name(self):
        for record in self:
            if record.spare_part_id:
                record.name = record.spare_part_id.name
            else:
                record.name = False
    
class LocalPartsInventory(models.Model):
    _name = 'local.parts.inventory'
    _description = 'Estoque de Peças da Usina'

    equipment_id = fields.Many2one('maintenance.equipment', string="Equipment", required=True, ondelete='cascade', index=True)
    spare_part_id = fields.Many2one('product.product', string='Spare Part', required=True, ondelete='restrict', index=True)
    quantity = fields.Float(string='Quantity', required=True, default=0.0)
    last_reorder_date = fields.Date(string='Last Reorder Date')
    next_reorder_date = fields.Date(string='Next Reorder Date', compute='_compute_next_reorder_date')
    hours_to_change = fields.Float(string='Hours to Change', compute='_compute_hours_to_change')

    equipment_name = fields.Char(related='equipment_id.name', string='Equipment Name')

    @api.depends('quantity')
    def _compute_adjusted_interval(self):
        for record in self:
            if record.quantity > 0:
                record.adjusted_interval = 1.0 / record.quantity
            else:
                record.adjusted_interval = 0.0

    adjusted_interval = fields.Float(string='Adjusted Interval', compute='_compute_adjusted_interval')

    @api.depends('spare_part_id')
    def _compute_spare_part_name(self):
        for record in self:
            if record.spare_part_id:
                record.name = record.spare_part_id.name
            else:
                record.name = False

    @api.depends('last_reorder_date')
    def _compute_next_reorder_date(self):
        for record in self:
            if record.last_reorder_date:
                record.next_reorder_date = record.last_reorder_date + timedelta(days=7)
            else:
                record.next_reorder_date = False

    @api.depends('equipment_id')
    def _compute_hours_to_change(self):
        for record in self:
            history_obj = self.env['spare.parts.change.history']
            history_ids = history_obj.search([('spare_part_id', '=', record.spare_part_id.id), ('equipment_id', '=', record.equipment_id.id)])
            if history_ids:
                record.hours_to_change = sum(history_ids.mapped('hours_to_change')) / len(history_ids)
            else:
                record.hours_to_change = 0.0

    @api.constrains('quantity')
    def _check_quantity(self):
        for record in self:
            if record.quantity < 0.0:
                raise ValidationError(_('Quantity cannot be negative.'))

    @api.depends('equipment_id')
    def _compute_equipment_name(self):
        for record in self:
            if record.equipment_id:
                record.equipment_name = record.equipment_id.name
            else:
                record.equipment_name = False